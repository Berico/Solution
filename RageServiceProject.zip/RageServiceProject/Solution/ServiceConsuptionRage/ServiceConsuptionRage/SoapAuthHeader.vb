﻿Imports System.ServiceModel
Imports System.ServiceModel.Channels

Public Class SoapAuthHeader



    Public Shared Sub Create(password As String)
        Dim auth = "Basic " + Convert.ToBase64String(Encoding.Default.GetBytes(password))
        Dim requestMessage As HttpRequestMessageProperty = New HttpRequestMessageProperty()
        requestMessage.Headers("Authorization") = auth
        OperationContext.Current.OutgoingMessageProperties(HttpRequestMessageProperty.Name) = requestMessage
    End Sub

End Class
