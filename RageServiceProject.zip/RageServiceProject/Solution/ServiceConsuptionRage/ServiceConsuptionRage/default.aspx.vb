﻿Imports System.Data.SqlClient
Imports System.IO
Imports System.Net
Imports System.Security.Policy
Imports System.ServiceModel
Imports System.ServiceModel.Channels
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Xml
Imports System.Xml.Serialization

Public Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim ServiceR As ServiceReferenceRage.testingSoapClient = New ServiceReferenceRage.testingSoapClient
        ServiceR.ClientCredentials.UserName.Password = "hajjwy2*uqyn1"

        Using (New OperationContextScope(ServiceR.InnerChannel))
            Try
                SoapAuthHeader.Create(ServiceR.ClientCredentials.UserName.Password)
                Dim Webrequest As WebRequest = WebRequest.Create("http://myrage.co.za/testing/testing.asmx?op=GetUsersTesting")
                Webrequest.Method = "POST"
                Webrequest.ContentType = "text/xml; charset=utf-8"

                Dim xml As String = "<?xml version='1.0' encoding='utf-8'?><soap:Envelope xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/'>  <soap:Body>    <GetUsersTesting xmlns='http://tempuri.org/' />  </soap:Body></soap:Envelope>"
                Dim branches As String = "<?xml version='1.0' encoding='utf-8'?>
<soap12:Envelope xmlns:xsi='http//www.w3.org/2001/XMLSchema-instance' xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:soap12='http://www.w3.org/2003/05/soap-envelope'>
  <soap12:Body>
    <GetBranches xmlns='http://tempuri.org/'>
      <Password>string</Password>
      <Database>string</Database>
      <BranchCode>string</BranchCode>
    </GetBranches>
  </soap12:Body>
</soap12:Envelope>"

                Dim myUsr() As ServiceReferenceRage.UserPermissions
                myUsr = ServiceR.GetUsersTesting(Passw.Text, Username.Text, BrchCode.Text)
                Dim CredentialCombo As String = Passw.Text + "" + Username.Text + "" + BrchCode.Text
                Dim CredentialComboService As String = myUsr.FirstOrDefault.user_password + "" + myUsr.FirstOrDefault.user_name + "" + myUsr.FirstOrDefault.branch_code

                Dim ds As New DataSet()
                Dim layoutXml As XmlDocument = New XmlDocument()
                layoutXml.LoadXml(branches)
                Dim SR As StringReader = New StringReader(layoutXml.DocumentElement.OuterXml)
                ds.ReadXml(SR)
                'Dim xmlStream As New System.IO.StreamReader(Server.MapPath("http://myrage.co.za/testing/testing.asmx"))
                'Dim ds As New DataSet()
                'ds.ReadXmlSchema(xmlStream)
                'xmlStream.Close()

                'ds.ReadXmlSchema(branches)
                SR.Close()

                'If (Username.Text <> myUsr.FirstOrDefault.user_name Or Username.Text = "" Or myUsr.FirstOrDefault.user_name = Nothing) Then
                '    Dim validUsername As Boolean = (String.Compare(Username.Text, myUsr.FirstOrDefault.user_name))
                '    Labela.Visible = True
                If (Username.Text = "") Then
                    Labela.Visible = True
                ElseIf (myUsr.FirstOrDefault.user_name Is Nothing) Then
                    Labela.Visible = True
                ElseIf (Username.Text <> myUsr.FirstOrDefault.user_name) Then
                    Dim validUsername As Boolean = (String.Compare(Username.Text, myUsr.FirstOrDefault.user_name))
                    Labela.Visible = True

                ElseIf (Passw.Text <> myUsr.FirstOrDefault.user_password Or Passw.Text = "" Or myUsr.FirstOrDefault.user_password IsNot Nothing) Then
                    Dim validPassword As Boolean = (String.Compare(Passw.Text, myUsr.FirstOrDefault.user_password))
                    Labelb.Visible = True
                ElseIf (BrchCode.Text <> myUsr.FirstOrDefault.branch_code Or BrchCode.Text = "" Or myUsr.FirstOrDefault.branch_code IsNot Nothing) Then
                    Dim validBranch As Boolean = (String.Compare(BrchCode.Text, myUsr.FirstOrDefault.branch_code))
                    Labelc.Visible = True
                Else
                    Dim validCombination As Boolean = (String.Compare(CredentialCombo, CredentialComboService))
                    Response.Redirect("Login.aspx")


                End If


            Catch ex As Exception
                Label4.Text = "" + ex.Message + "" + "The entered credentials are not valid."

            Finally

            End Try
        End Using

    End Sub

End Class