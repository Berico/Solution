﻿Imports System.IO
Imports System.Net
Imports System.ServiceModel
Imports System.Xml

Public Class Users
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim ServiceR As ServiceReferenceRage.testingSoapClient = New ServiceReferenceRage.testingSoapClient
        ServiceR.ClientCredentials.UserName.Password = "hajjwy2*uqyn1"

        Using (New OperationContextScope(ServiceR.InnerChannel))
            Try
                SoapAuthHeader.Create(ServiceR.ClientCredentials.UserName.Password)
                Dim Webrequest As WebRequest = WebRequest.Create("http://myrage.co.za/testing/testing.asmx")
                Webrequest.Method = "POST"
                Webrequest.ContentType = "text/xml; charset=utf-8"
                Dim branches As String = "<?xml version='1.0' encoding='utf-8'?>
<soap:Envelope xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/'>
  <soap:Body>
    <GetUsersTesting xmlns='http://tempuri.org/'>
      <Password>string</Password>
      <Database>string</Database>
      <BranchCode>string</BranchCode>
    </GetUsersTesting>
  </soap:Body>
</soap:Envelope>"
                Dim P As String = "1234"
                Dim B As String = "Head Office"
                Dim D As String = "Liezel"
                Dim myStk() As ServiceReferenceRage.UserPermissions
                myStk = ServiceR.GetUsersTesting(P, D, B)

                Dim ds As New DataSet()
                Dim layoutXml As XmlDocument = New XmlDocument()
                layoutXml.LoadXml(branches)
                Dim SR As StringReader = New StringReader(layoutXml.DocumentElement.OuterXml)
                ds.ReadXml(SR)


                Dim dt As DataTable = New DataTable()
                dt.Columns.Add("user_name")
                dt.Columns.Add("user_password")
                dt.Columns.Add("branch_code")
                dt.Columns.Add("is_head_office_user")
                dt.Columns.Add("is_locked_to_branch")
                dt.Columns.Add("pos_sequence")
                dt.Columns.Add("maintenance_sequence")
                dt.Columns.Add("transaction_sequence")
                dt.Columns.Add("isp27")


                Dim counter As Integer = myStk.Length
                Dim dr As DataRow

                If counter > 0 Then
                    Dim i As Integer = 0
                    While i < counter
                        dr = dt.NewRow()
                        'dt.Columns.Count()
                        dr("user_name") = myStk(i).user_name
                        dr("user_password") = myStk(i).user_password
                        dr("branch_code") = myStk(i).branch_code
                        dr("is_head_office_user") = myStk(i).is_head_office_user
                        dr("is_locked_to_branch") = myStk(i).is_locked_to_branch
                        dr("pos_sequence") = myStk(i).pos_sequence
                        dr("maintenance_sequence") = myStk(i).maintenance_sequence
                        dr("transaction_sequence") = myStk(i).transaction_sequence
                        dr("isp27") = myStk(i).isp27

                        dt.Rows.Add(dr)

                        i += 1
                    End While

                    GridView1.DataSource = dt
                    GridView1.DataBind()

                Else
                    Response.Write("no data")

                End If
            Catch ex As Exception
                Label1.Text = ex.Message

            Finally

            End Try

        End Using
    End Sub

End Class